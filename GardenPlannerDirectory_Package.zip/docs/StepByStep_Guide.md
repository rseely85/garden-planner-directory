# Garden Planner Directory — Step-by-Step Setup Guide

## Prerequisites
- GitHub account + repo
- GitHub CLI (gh), jq
- Node.js, npm, Git

## Steps
1. Add docs/, data/, scripts/ into repo and commit.
2. Edit and run scripts/setup_all.sh to auto-create project + issues.
3. Setup Firebase project, apply rules, seed data.
4. Scaffold Next.js project with Copilot.
5. Add env vars (.env.local).
6. Run locally: npm install && npm run dev
7. Deploy via Vercel/Netlify.

See PDF requirements for details.
