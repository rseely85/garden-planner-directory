import React from 'react';
import SupplierCard from '../components/SupplierCard';
import PlannerSidebarMatches from '../components/PlannerSidebarMatches';

export default function HomePage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold">Garden Planner Directory</h1>
      <p className="mt-2 text-gray-600">TODO: Add hero section, how it works, featured suppliers.</p>
      {/* TODO: Render SupplierCard and PlannerSidebarMatches */}
    </div>
  );
}
