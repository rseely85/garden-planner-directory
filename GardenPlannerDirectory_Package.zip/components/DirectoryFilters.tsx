import React from 'react';

export default function DirectoryFilters(props: any) {
  return (
    <div className="border p-4 rounded bg-white shadow-sm">
      <p className="text-gray-500">TODO: DirectoryFilters component</p>
    </div>
  );
}
