import React from 'react';

export default function SupplierCard(props: any) {
  return (
    <div className="border p-4 rounded bg-white shadow-sm">
      <p className="text-gray-500">TODO: SupplierCard component</p>
    </div>
  );
}
