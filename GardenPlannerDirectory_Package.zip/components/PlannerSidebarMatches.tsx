import React from 'react';

export default function PlannerSidebarMatches(props: any) {
  return (
    <div className="border p-4 rounded bg-white shadow-sm">
      <p className="text-gray-500">TODO: PlannerSidebarMatches component</p>
    </div>
  );
}
