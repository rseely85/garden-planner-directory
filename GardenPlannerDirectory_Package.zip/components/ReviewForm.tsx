import React from 'react';

export default function ReviewForm(props: any) {
  return (
    <div className="border p-4 rounded bg-white shadow-sm">
      <p className="text-gray-500">TODO: ReviewForm component</p>
    </div>
  );
}
